package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParallelProjectSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParallelProjectSpringBootApplication.class, args);
	}

}
