
package com.pro.dao;
//import org.junit.Test;

import static org.junit.Assert.*;

import org.junit.Test;

public class BankDaoTestImpl {
//	//positive response
   BankDaoImpl dao=new BankDaoImpl();
   
   public void test1(){
       int deposit=500;
       long balance=dao.showBalance(1);
       long result=dao.deposit(1, deposit);
       long expectedResult=balance+500;
       
     assertEquals(expectedResult,result);
       System.out.println(expectedResult=result);
   }
   
   @Test
   public void test2(){
       int withdraw=500;
       long balance=dao.showBalance(1);
       long result=dao.withdraw(1, withdraw);
       long expectedResult=balance-500;
       assertEquals(expectedResult,result);
       System.out.println(expectedResult+"="+result);
   }
   
   @Test
   public void test3(){
       int fund=500;
       long balance=dao.showBalance(1);
       long result=dao.FundTransfer(1,3,fund);
       long expectedResult=balance-500;
       assertEquals(expectedResult,result);
       System.out.println(expectedResult=result);
   }
   
   



}
   
//    @Test
//    public void createAcc_1()
//    {
//        Bank bank=new Bank();
//        bank.setAccBalance(1234);
//        bank.setAccNo(1001);
//        bank.setAccType("savings");
//        bank.setMobileNo(989899898);
//        bank.setAccName("qwerty");
//        long AccNum=dao.createAccount(bank);
//        
//        Assert.assertEquals(1001, AccNum);
//        
//    }
//    //negative response
//        @Test
//        public void createAcc_2()
//        {
//            Bank bank=new Bank();
//            bank.setAccBalance(1234);
//            bank.setAccNo(1000);
//            bank.setAccType("savings");
//            bank. setMobileNo(989899898);
//            bank.setAccName("qwerty");
//            long AccNum=dao.createAccount(bank);
//            
//            Assert.assertEquals(10000,AccNum);
//            
//        }




