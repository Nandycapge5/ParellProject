package com.pro.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

//import com.empcrud.dao.JPAUtil;
import com.pro.bean.Bank;
import com.pro.bean.Transaction;
import javax.persistence.EntityManager;
public class BankDaoImpl implements BankDao {

EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");

	private EntityManager entityManager = emf.createEntityManager();
	
	 //private EntityManager entityManager;

	  

//	     public BankDaoImpl() 
//	     {
//	        entityManager = JPAUtil.getEntityManager();
//	    }
	
	@Override
	public long createAccount(Bank bank) {

		entityManager.persist(bank);
		return bank.getAccNo();
	}

	@Override
	public long showBalance(long accNo) {
		// entityManager.persist(accNo);
		Bank account = entityManager.find(Bank.class, accNo);
		return account.getAccBalance();

		// return value;
	}

	@Override
	public long deposit(long accNo1, int depositAmt) {
		 Bank account = entityManager.find(Bank.class, accNo1);
	        long oldbalance=account.getAccBalance();
	        long newBalance=oldbalance+depositAmt;
	        account.setAccBalance(newBalance);
	        entityManager.merge(account);
	        
	        
	        Transaction bt=new Transaction();
	        bt.setFromAcc(accNo1);
	        bt.setOldBal(oldbalance);
	        bt.setNewbal(newBalance);
	        bt.setTransType("deposit");
	        entityManager.persist(bt);
	       
	        
	        
	        return newBalance;
	}

	@Override
	public long withdraw(long accNo1, int withdrawAmt) {
		Bank account = entityManager.find(Bank.class, accNo1);
        long oldbalance=account.getAccBalance();
        long newBalance=oldbalance-withdrawAmt;
        account.setAccBalance(newBalance);
        entityManager.merge(account);
		

		
		Transaction bt=new Transaction();
        bt.setFromAcc(accNo1);
        bt.setOldBal(oldbalance);
        bt.setNewbal(newBalance);
        bt.setTransType("withdraw");
        entityManager.persist(bt);
        return newBalance;
		
		 	    
	}

	@Override
	public long FundTransfer(long accNo3, long accNo4, long amount) {
		Bank account = entityManager.find(Bank.class, accNo3);
        long oldbalance=account.getAccBalance();
        long newBalance=oldbalance-amount;
        account.setAccBalance(newBalance);
        entityManager.merge(account);
		
        Transaction bt=new Transaction();
        bt.setFromAcc(accNo3);
        bt.setOldBal(oldbalance);
        bt.setNewbal(newBalance);
        bt.setTransType("withdraw");
        entityManager.persist(bt);
        
		

		
		
		 Bank account1 = entityManager.find(Bank.class, accNo4);
	        long oldbalance1=account.getAccBalance();
	        long newBalance1=oldbalance+amount;
	        account.setAccBalance(newBalance);
	        entityManager.merge(account);
	        Transaction t=new Transaction();
	        t.setFromAcc(accNo4);
	        t.setOldBal(oldbalance);
	        t.setNewbal(newBalance);
	        t.setTransType("deposit");
	        entityManager.persist(t);
	        
	        
	    return newBalance;
	}

	@Override
	public void printTransaction() {
		// TODO Auto-generated method stub
	
	
		 TypedQuery<Transaction> q2=entityManager.createQuery("select c from Transaction c",Transaction.class);
	        List<Transaction> l1=q2.getResultList();
	        for(Transaction em1:l1)
	        {
	            System.out.println(em1.getTid()+"  "+em1.getFromAcc()+"  "+em1.getToAcc()+" "+em1.getOldBal()+" "+em1.getNewbal()+" "+em1.getTransType());
	        }
		        
	}

	@Override
	public void beginTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().begin();

	}

	@Override
	public void commitTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().commit();

	}
	
}