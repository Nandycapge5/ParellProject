package com.pro.dao;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.pro.bean.Bank;

public class BankDaoTestImple {

	
	
	 BankDaoImpl dao=new BankDaoImpl();
	 
	 
	 public void test1(){
         int deposit=500;
         long balance=dao.showBalance(1);
         long result=dao.deposit(1, deposit);
         long expectedResult=balance+500;
         assertEquals(expectedResult,result);
         System.out.println(expectedResult=result);
     }
     
     @org.junit.Test
     public void test2(){
         int withdraw=500;
         long balance=dao.showBalance(1);
         long result=dao.withdraw(1, withdraw);
         long expectedResult=balance-500;
         assertEquals(expectedResult,result);
         System.out.println(expectedResult+"="+result);
     }
     
     @org.junit.Test
     public void test3(){
         int fund=500;
         long balance=dao.showBalance(1);
         long result=dao.FundTransfer(1,3,fund);
         long expectedResult=balance-500;
         assertEquals(expectedResult,result);
         System.out.println(expectedResult=result);
     }
     
     



}

