package com.pro.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="trans")
public class Transaction {
	@Column(length=10)
	@Id
	@GeneratedValue
	private long tid;
	@Column(length=10)
	private long fromAcc;
	@Column(length=10)
	private long toAcc;
	@Column(length=10)
	private long oldBal;
	@Column(length=10)
	private long newBal;
	@Column(length=10)
	private String transType;

	public long getTid() {
		return tid;
	}

	public void setTid(long tid) {
		this.tid = tid;
	}

	public long getFromAcc() {
		return fromAcc;
	}

	public void setFromAcc(long fromAcc) {
		this.fromAcc = fromAcc;
	}

	public long getToAcc() {
		return toAcc;
	}

	public void setToAcc(long toAcc) {
		this.toAcc = toAcc;
	}

	public long getOldBal() {
		return oldBal;
	}

	public void setOldBal(long oldBal) {
		this.oldBal = oldBal;
	}

	public long getNewbal() {
		return newBal;
	}

	public void setNewbal(long newbal) {
		this.newBal = newbal;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	@Override
	public String toString() {
		return "Transcation [tid=" + tid + ", fromAcc=" + fromAcc + ", toAcc=" + toAcc + ", oldBal=" + oldBal
				+ ", newbal=" + newBal + ", transType=" + transType + "]";
	}

}
