package com.pro.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Bank {
	private String accName;
	@Id
	@GeneratedValue
	@Column(length=5)
	private long accNo;
	@Column(length=10)
	private String accType;
	@Column(length=10)
	private String branch;
	@Column(length=10)
	private long accBalance;
	@Column(length=10)
	private long mobileNo;

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName1) {
		accName = accName1;
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo1) {
		accNo = accNo1;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType1) {
		accType = accType1;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch1) {
		branch = branch1;
	}

	public long getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(long accBalance1) {
		accBalance = accBalance1;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo1) {
		mobileNo = mobileNo1;
	}

	@Override
	public String toString() {
		return "Bank [accName=" + accName + ", accNo=" + accNo + ", accType=" + accType + ", branch=" + branch
				+ ", accBalance=" + accBalance + ", mobileNo=" + mobileNo + "]";
	}

}
